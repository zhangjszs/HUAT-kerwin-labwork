
#ifndef CAMERA_CALIBRATION_H
#define CAMERA_CALIBRATION_H

#pragma once


#include <iostream>
#include <sstream>
#include <string>
#include <ctime>
#include <cstdio>

#include <opencv2/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>

using namespace cv;
using namespace std;


enum { DETECTION = 0, CAPTURING = 1, CALIBRATED = 2 };


class Settings
{
public:
    Settings();
    enum Pattern { NOT_EXISTING, CHESSBOARD, CIRCLES_GRID, ASYMMETRIC_CIRCLES_GRID };
    enum InputType { INVALID, CAMERA, VIDEO_FILE, IMAGE_LIST };

    // ���л����
    void write(FileStorage& fs) const;                        //Write serialization for this class
 

    // ���л�����
    void read(const FileNode& node);                          //Read serialization for this class
 

    // У������
    void validate();

    // ��ȡ��һ��ͼ���ļ�
    Mat nextImage();

    //
    static bool readStringList(const string& filename, vector<string>& l);

    //
    static bool isListOfImages(const string& filename);

public:
    Size boardSize;              // ���̴�С��The size of the board -> Number of items by width and height
    Pattern calibrationPattern;  // �궨ģʽ��One of the Chessboard, circles, or asymmetric circle pattern
    float squareSize;            // ����ߴ磬The size of a square in your defined unit (point, millimeter,etc).
    int nrFrames;                // ����У׼�������֡����The number of frames to use from the input for calibration
    float aspectRatio;           // ��۱�����The aspect ratio
    int delay;                   // �����������ͣʱ�䣬In case of a video input
    bool writePoints;            // ������������㣬Write detected feature points
    bool writeExtrinsics;        // ����ⲿ������Write extrinsic parameters
    bool writeGrid;              // Write refined 3D target grid points
    bool calibZeroTangentDist;   // ���������䣬Assume zero tangential distortion
    bool calibFixPrincipalPoint; // �������ĵ���Ҫ�㣬Fix the principal point at the center
    bool flipVertical;           // ��ˮƽ���귭תץ����ͼ��Flip the captured images around the horizontal axis
    string outputFileName;       // ����ļ�����The name of the file where to write
    bool showUndistorted;        // У׼����ʾʧ��ͼ��Show undistorted images after calibration
    string input;                // �����ļ�����The input ->
    bool useFisheye;             // use fisheye camera model for calibration
    bool fixK1;                  // fix K1 distortion coefficient
    bool fixK2;                  // fix K2 distortion coefficient
    bool fixK3;                  // fix K3 distortion coefficient
    bool fixK4;                  // fix K4 distortion coefficient
    bool fixK5;                  // fix K5 distortion coefficient

    int cameraID;
    vector<string> imageList;
    size_t atImageList;
    VideoCapture inputCapture;
    InputType inputType;
    bool goodInput;
    int flag;

private:
    string patternToUse;
};





void read(const FileNode& node, Settings& x, const Settings& default_value = Settings());


static double computeReprojectionErrors(const vector<vector<Point3f> >& objectPoints,
    const vector<vector<Point2f> >& imagePoints,
    const vector<Mat>& rvecs, const vector<Mat>& tvecs,
    const Mat& cameraMatrix, const Mat& distCoeffs,
    vector<float>& perViewErrors, bool fisheye);

static void calcBoardCornerPositions(Size boardSize, float squareSize, vector<Point3f>& corners,
    Settings::Pattern patternType /*= Settings::CHESSBOARD*/);

static bool runCalibration(Settings& s, Size& imageSize, Mat& cameraMatrix, Mat& distCoeffs,
    vector<vector<Point2f> > imagePoints, vector<Mat>& rvecs, vector<Mat>& tvecs,
    vector<float>& reprojErrs, double& totalAvgErr, vector<Point3f>& newObjPoints,
    float grid_width, bool release_object);

// Print camera parameters to the output file
static void saveCameraParams(Settings& s, Size& imageSize, Mat& cameraMatrix, Mat& distCoeffs,
    const vector<Mat>& rvecs, const vector<Mat>& tvecs,
    const vector<float>& reprojErrs, const vector<vector<Point2f> >& imagePoints,
    double totalAvgErr, const vector<Point3f>& newObjPoints);

bool runCalibrationAndSave(Settings& s, Size imageSize, Mat& cameraMatrix, Mat& distCoeffs,
    vector<vector<Point2f> > imagePoints, float grid_width, bool release_object);



#endif // !CAMERA_CALIBRATION_H
