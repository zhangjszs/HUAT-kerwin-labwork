#include<stdio.h>
 enum DAY { MON, TUE, WED=99, THU, FRI, SAT, SUN };
 const char *display[7]={"Monesday","Tuesday","wednesday","Thursday","Friday","Saturday","Sunday"};
 int  main()
{   
    int x, y, z;
    x = 10;
    y = 20;
    z = 30;

    enum DAY yesterday, today, tomorrow;

    yesterday = MON;
    today     = TUE;
    tomorrow  = WED;

	printf("%d %d %d \n",x,y,z);

    printf("%d %d %d \n", yesterday, today, tomorrow);

	printf("Today is %s\n",display[today]);
	
	return 0;
}
